TSP Metaheuristics Project

Requirements:
- Python 3
- matplotlib

Run experiments:
python experiments.py

Generate plots:
python plots.py
